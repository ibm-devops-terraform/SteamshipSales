import React, { Component } from 'react';

export class FetchData extends Component {
  static displayName = FetchData.name;

  constructor(props) {
      super(props);
      this.state = { staffsales: [], loading: true };
      

  }


  componentDidMount() {
    this.populatestaffsales();
    }
 



    static renderstaffsalesTable(staffsales) {

        this.state = { visible: true };
        
  
        return (

          

          
            <table className='table table-bordered' aria-labelledby="tabelLabel">
        <thead>
                  
                </thead>
                <tbody>
                    <table className='table .table-condensed'>
                    <tr>
                            <th width='50px'>Employee Name</th>
                            <th width='50px'>Sales Amount</th>

                        </tr>
                    </table>
                    {staffsales.map(staffsale =>
                        <tr key={staffsale.seq} onClick={this.state = { visible: false }}>
                                   
                         
                         
                            <tr>
                                <td width='50px'>{staffsale.emp_First_Name}</td>
                                <td width='50px'>{staffsale.sales_Amount}</td>
                                   
                            </tr>
                            <table>
                                <tr>
                                    <div id={staffsale.seq} hidden={this.state.visible}>
                                    <td width="10%">{staffsale.emp_First_Name}</td>
                                    <td width="50%">{staffsale.emp_Last_Name}</td>
                                    <td width="10%">{staffsale.sales_Count}</td>
                                    <td width="50%">{staffsale.mgr_First_Name}</td>
                                    <td width="50%">{staffsale.mgr_Last_Name}</td>
                                </div>
                           
                                </tr>
                            </table>    
                        </tr>


          )}
        </tbody>
        </table>

       

    );
    }

  

  render() {
    let contents = this.state.loading
      ? <p><em>Loading...</em></p>
        : FetchData.renderstaffsalesTable(this.state.staffsales);

      return (
          <div width="50%">
        <h1 id="tabelLabel" >Staff Sales</h1>
              <p>This component demonstrates fetching data from the server.</p>
              {contents}
      </div>
    );
  }

    async populatestaffsales() {
       
      const response = await fetch('https://localhost:44318/api/Sales');
    const data = await response.json();
      this.setState({ staffsales: data, loading: false });
  }
}
