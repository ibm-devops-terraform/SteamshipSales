﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace SteamShip_Sales.Models.DB
{
    public partial class SteamShipSalesContext : DbContext
    {
        public SteamShipSalesContext()
        {
        }

        public SteamShipSalesContext(DbContextOptions<SteamShipSalesContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Company> Company { get; set; }
        public virtual DbSet<Employee> Employee { get; set; }
        public virtual DbSet<Sales> Sales { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("SteamShipSales");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
                      

            modelBuilder.Entity<Sales>(entity =>
            {

                entity.HasNoKey();
                entity.Property(e => e.seq)
                   .HasColumnName("seq");

                entity.Property(e => e.Emp_First_Name)
                    .HasColumnName("Emp_First_Name");
                   

                entity.Property(e => e.Emp_Last_Name).HasColumnName("Emp_Last_Name");

                entity.Property(e => e.Mgr_First_Name)
                  .HasColumnName("Mgr_First_Name");


                entity.Property(e => e.Mgr_Last_Name).HasColumnName("Mgr_Last_Name");

                entity.Property(e => e.Sales_Count).HasColumnName("Sales_Count");

                entity.Property(e => e.Sales_Amount)
                    .HasColumnName("Sales_Amount")
                    .HasColumnType("decimal(18, 2)");
            });

            

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
