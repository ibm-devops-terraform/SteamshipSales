﻿using System;
using System.Collections.Generic;

namespace SteamShip_Sales.Models.DB
{
    public partial class Sales
    {
        public System.Int64 seq { get; set; }

        public string Emp_First_Name { get; set; }
        public string Emp_Last_Name { get; set; }
        public decimal? Sales_Amount { get; set; }
       public int Sales_Count { get; set; }

        public string Mgr_First_Name { get; set; }
        public string Mgr_Last_Name { get; set; }
    }
}
