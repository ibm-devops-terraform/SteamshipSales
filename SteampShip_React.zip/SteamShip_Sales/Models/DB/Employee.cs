﻿using System;
using System.Collections.Generic;

namespace SteamShip_Sales.Models.DB
{
    public partial class Employee
    {
        public int EmployeeId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int? ManagerId { get; set; }
        public int? CompanyId { get; set; }
    }
}
